import './App.css';
import React, { useState } from 'react'
import Footer from './Components/Footer';

function App() {
  const [input, setInput] = useState({
    weight : undefined,
    height : undefined
  });

  const [bmi, setBMI] = useState('')


  function calculate(e){
    e.preventDefault();

    if(input.weight && input.height){
    const heightInMeters = input.height /100;
    const bmi = (input.weight /(heightInMeters * heightInMeters)).toFixed(2)
    setBMI(bmi);
    
   }
   else{
    alert('Input Must be Required')
   }
  }
  
  return (
    <>
      <div className='m-0 font-[Poppins,sans-serif] bg-[url(https://4kwallpapers.com/images/wallpapers/gradient-background-1280x1280-10974.jpg)] flex justify-center bg-cover bg-no-repeat items-center h-screen'>
        
        <div className="bg-white/20 rounded-3xl p-8 shadow-lg backdrop-blur-md border border-white/20 text-center max-w-[400px] w-full text-white">
        <h2 className="text-4xl mb-5 text-black">BMI Calculator</h2>
          <form className="mb-4">
            <label className="block mb-1 text-gray-100">
              Weight (kg) 
            </label>
            <input type='number' placeholder='Enter Weight' name='weight' value ={input.weight} onChange={(event)=>
              setInput({...input, weight:event.target.valueAsNumber})} className="w-full py-2.5 px-3 border-none rounded-lg text-base bg-white/30 text-black outline-none placeholder:text-gray-200">
              </input>
            <br />
            <br/>
            <label className="block mb-1 text-gray-100">
              Height (cm)
            </label>
            <input type='number' placeholder='Enter Height' name='height' value ={input.height} onChange={(event)=>
              setInput({...input, height:event.target.valueAsNumber})} className="w-full py-2.5 px-3 border-none rounded-lg text-base bg-white/30 text-black outline-none placeholder:text-gray-200"></input>
            <button onClick={calculate} className="mt-5 bg-gradient-to-r from-[#ff8a00] to-[#e52e71] text-white border-none py-4 px-5 rounded-full text-base cursor-pointer transition-all duration-300 hover:bg-gradient-to-r hover:from-[#e52e71] hover:to-[#ff8a00]"> Submit</button>
          </form>


          {bmi && (
            <div className="my-8 mx-7">
              <h3 className="text-xl text-[#032cfc] ">Your BMI: {bmi}</h3>
            </div>
          )}
        </div>
      </div>
      <Footer/>
    </>
  )
}

export default App
